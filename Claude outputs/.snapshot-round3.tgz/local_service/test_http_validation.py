"""HTTP boundary tests without opening sockets or using real workstation data."""
import io
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import Mock

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from local_service.workbench_service import WorkbenchRequestHandler


class HttpBoundaryTests(unittest.TestCase):
    def handler(self):
        handler = object.__new__(WorkbenchRequestHandler)
        handler.headers = {"Host": "127.0.0.1:43117"}
        handler.service = Mock()
        handler._json = Mock()
        return handler

    def test_invalid_body_lengths_are_rejected_before_reading(self):
        for length in ("-1", "-100", "abc", "1000001"):
            with self.subTest(length=length):
                handler = self.handler()
                handler.headers["Content-Length"] = length
                handler.rfile = Mock()
                with self.assertRaises(ValueError):
                    handler._body()
                handler.rfile.read.assert_not_called()

    def test_invalid_list_limits_return_json_error(self):
        for route in ("sample-library", "cohort/samples", "phenotypes"):
            handler = self.handler()
            handler.path = f"/api/{route}?limit=invalid"
            handler.do_GET()
            self.assertEqual(handler._json.call_args.args[1], 400)

    def test_unicode_download_names_are_valid_http_headers(self):
        with tempfile.TemporaryDirectory() as directory:
            filename = '研究 "sample".vcf.gz'
            source = Path(directory) / filename
            source.write_bytes(b"synthetic content")
            handler = self.handler()
            headers = {}
            def send_header(name, value):
                value.encode("latin-1")  # BaseHTTPRequestHandler's wire encoding
                self.assertNotIn("\r", value)
                self.assertNotIn("\n", value)
                headers[name] = value
            handler.send_header = send_header
            handler.send_response = Mock()
            handler.end_headers = Mock()
            handler.wfile = io.BytesIO()
            handler._file(source)
            self.assertIn("filename*=UTF-8''", headers["Content-Disposition"])
            self.assertEqual(handler.wfile.getvalue(), b"synthetic content")


if __name__ == "__main__":
    unittest.main()
