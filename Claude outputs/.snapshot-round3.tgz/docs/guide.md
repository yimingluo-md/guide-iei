---
title: User Guide
nav_order: 2
has_children: true
---

# User Guide

Practical guidance for clinicians and wet-lab scientists. The guide assumes
familiarity with clinical genetics — candidate genes, variant classes,
population frequencies — and assumes **no** software or bioinformatics
experience beyond a download and a double-click. Chapters follow the order in
which the work is encountered: orientation, installation, dataset setup,
then the first analysis.

The technical detail behind every step is documented in the
[Reference](reference.md) section, linked from each chapter.

Screenshots illustrate synthetic demonstration data and example workstation
states. Their variants, scores, and classifications are not validation controls
or evidence about real patients. Your installed resources and counts may differ.

Stuck during setup or import? Start with [Troubleshooting](TROUBLESHOOTING.md).

## Chapters

1. [What GUIDE-IEI does](guide/01-what-guide-iei-does.md)
2. [Install it on your computer](guide/02-install.md)
3. [Set up the annotation datasets](guide/03-datasets.md)
4. [Your first exome: VCF to reviewed shortlist](guide/04-first-exome.md)
5. [Whole-genome analysis](guide/05-whole-genome.md)
6. [Trio analysis](guide/06-trio.md)
7. [Phenotypes and the Sample Library](guide/07-phenotypes-and-library.md)
8. [Cohort analysis: review and search](guide/08-cohort-search.md)
9. [Reading a variant page](guide/09-reading-a-variant.md)
10. [Quality control and sanity checks](guide/10-quality-control.md)
