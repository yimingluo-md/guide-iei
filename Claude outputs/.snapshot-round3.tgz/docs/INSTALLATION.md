---
title: "Installation & requirements"
parent: Reference
nav_order: 1
---

# Installation & requirements

[Manual home](index.md)

## The setup check

The standalone Mac app, source-tree `.command`, and Windows launcher run the
setup check automatically. For a direct terminal launch, run it yourself: it checks everything below, prints an
exact fix for anything missing, and `--install` installs supported missing
prerequisites. A Mac needs no administrator rights or Homebrew; Ubuntu/WSL2
may request the Linux user's sudo password for system packages:

```bash
# report what is present / missing (changes nothing)
bash scripts/setup_environment.sh

# install supported missing prerequisites
bash scripts/setup_environment.sh --install
```

What it needs to find (or install):

- **A container runtime** — Docker, Podman, Singularity, or Apptainer.
  - *macOS:* `--install` sets up a no-admin, Homebrew-free stack (Lima +
    Colima + the Docker CLI, all version-pinned and SHA-256-verified) in
    `~/.iei-variant-review/tools/`. An existing Docker Desktop / Podman
    install is detected and used instead.
  - *Linux / WSL2:* a container runtime is a system component, so the script
    prints the exact install commands and runs them only after an explicit
    yes (existing docker/podman/singularity installs are always preferred —
    Docker Desktop is **not** required on WSL2). The Windows double-click
    launcher does not automatically install a second native Docker engine;
    it points Docker Desktop users to WSL integration instead.
- **Python 3.9+** with **PyYAML** (`requirements.txt`; `--install` handles it)
  — for the config parser and local service. On a clean Mac, `--install`
  downloads a pinned, checksum-verified, relocatable native CPython build into
  the managed tools folder; Xcode Command Line Tools are not required.
- **Node.js 22.13+** with npm — for the local review UI. `--install` places
  the official nodejs.org build in the managed tools folder when no suitable
  Node is found; `scripts/start_workbench.sh` finds it there automatically.
- Disk for references: the VEP cache alone is ~25 GB; dbNSFP is a ~50 GB
  download (academic registration required — see
  [Annotation dataset setup](DATASET_SETUP.md)); SpliceAI (if enabled) adds
  tens of GB more.

No Git, Xcode, system Python, VEP, LOFTEE, bgtools, or Perl installation is
needed by the standalone Mac app — annotation software runs in the container.
The setup script never edits your shell profile. Its managed tools live under
`~/.iei-variant-review/tools/`, but optional package-manager installations,
container images, and the Colima/Lima VM may live elsewhere. Back up the
library before uninstalling; see [backup and restore](SAMPLE_LIBRARY_AND_STORAGE.md#backup-and-restore).

Optional but recommended: **native `bcftools`/`tabix`/`bgzip`** on the host.
Without them every htslib operation runs through the container, which works
but is typically 5–20× slower over macOS bind mounts. `--install` adds them
automatically via conda, Homebrew, or apt when one is available; the pinned
in-container BCFtools/liftover used for GRCh37 intake is unaffected.

## Supported platforms

| Platform | Status | Notes |
|----------|--------|-------|
| **Linux** | ✅ native | Primary target. Run directly. |
| **macOS 13+** (Intel or Apple Silicon) | ✅ native | Scripts are Bash-3.2-compatible (macOS ships Bash 3.2); run the Linux container with Docker Desktop, Podman, or Colima. The bundled Colima release requires macOS 13 or newer. |
| **Windows** | ✅ via **WSL2** only | Not supported from native Windows shells or Git Bash. See below. |

The runner is a set of **Bash** scripts that call standard Unix tools
(`awk`, `sed`, `sort`, `gzip`, `curl`/`wget`, `python3`, `rsync`) plus a Linux
**container** (`ensemblorg/ensembl-vep`). Anything that needs `bcftools` /
`tabix` / `bgzip` runs them natively if present, or falls back to the container.

### Windows: use WSL2

Native Windows (`cmd`, PowerShell, or bare Git Bash) **cannot** run this — the
scripts need a real Unix shell + coreutils, and the VEP image is Linux-only.
The supported route is **WSL2** (Windows Subsystem for Linux 2), which is a real
Linux kernel:

For the graphical route, fully extract the repository ZIP and double-click
`desktop\windows\GUIDE-IEI.bat`. It validates a real WSL2 distribution with
Bash, offers or explains `wsl --install -d Ubuntu` when missing, copies a clean
snapshot to `~/guide-iei`, installs missing Ubuntu prerequisites, and opens the
Windows browser. Errors remain visible and are logged under
`%LOCALAPPDATA%\GUIDE-IEI\logs`.

Install **[Docker Desktop](https://www.docker.com/products/docker-desktop/)**
and enable its **WSL2 backend** (Settings → Resources → WSL integration) before
running VEP annotation. Docker is not needed merely to import and review an
already annotated VCF. Terminal users may instead install WSL2/Ubuntu and a
container runtime themselves, then run the Linux commands above inside Ubuntu.

If Windows blocks the unsigned launcher, use the supported
[direct WSL startup instructions](guide/02-install.md#windows-start-directly-in-wsl).
They separate PowerShell installation commands from Ubuntu startup commands.
Publisher signing is planned; do not disable Windows security to launch the app.

> **Performance caveat.** Keep the clone **and** the large reference files on
> the **WSL2 filesystem** (`~/...` inside the distro), *not* on a Windows drive
> under `/mnt/c/...`. Cross-filesystem I/O to `/mnt/c` is very slow, which badly
> hurts the multi-GB tabix reference reads (dbNSFP, SpliceAI, CADD).

> **Disk-space caveat.** The WSL2 filesystem is a virtual-disk file on `C:` by
> default, growing with use — it must accommodate the reference datasets
> (see [dataset planning](guide/03-datasets.md#plan-disk-space-first)). If `C:`
> is small, plan the Linux distribution's location before installing datasets.
> Follow the [installation chapter](guide/02-install.md) and involve IT for
> an existing distribution: `wsl --unregister` permanently deletes its data.
> Datasets on a `/mnt/*` drive via the Storage page work but pay the
> cross-filesystem penalty above.

## Where to keep the clone (cloud-sync note)

Keep the git clone in a **non-synced** location (e.g. `~/repos/`) and do all
`git pull` / `git push` there. **Do not run git directly inside a OneDrive /
Dropbox / Google Drive folder** — those providers block or corrupt the `.git`
directory (OneDrive returns "Operation not permitted" on `.git`, and syncing
git's internal object files mid-write can corrupt the repo).

If you want a copy inside a synced folder to edit/run from, use the helper,
which copies the working tree **without** `.git`:

```bash
# refresh the OneDrive snapshot after a git pull (edit DEST or set ONEDRIVE_DEST)
scripts/sync_to_onedrive.sh [DEST]
```

## Verify the installation (no container, no downloads)

A self-contained smoke test exercises the whole wiring — config parsing, the
VEP command builder, the container-command assembly (dry run), and protein
matching on a simulated VEP output — without needing Docker or any reference
data:

```bash
bash test/test_dry_run.sh
```

Expected tail:

```
[1/3] builder --json
  argv tokens: 40  mounts: 7
[2/3] run_annotation.sh --dry-run
  dry-run assembled OK
[3/3] clinvar_aa_match.py on simulated VEP output
  [aa_match] ref_residues=2 records=3 missense=2 matched=1 csq_usable=True
  match flag present
ALL DRY-RUN CHECKS PASSED
```

Focused unit tests for protein matching and its source-catalog builder:

```bash
python3 test/test_build_command.py
python3 test/test_aa_match.py
python3 test/test_clinical_protein_catalog.py
```

Once annotation datasets are installed, the small public regression panel
exercises the installed data — not only the command wiring:

```bash
bash scripts/run_annotation_regression.sh
```

It annotates eight public GRCh38 controls (three LoGoFunc OR4F5 missense
alleles, NCSTN frameshift, STAT3 missense, IL2RG splice donor, IL2RG
stop-gained, and a TERT promoter variant), then asserts the PTC-based LOFTEE
50-bp correction, LOFTEE, AlphaMissense, CADD, SpliceAI, ClinVar, and ClinVar
amino-acid matching. LoGoFunc and PromoterAI checks can report `SKIP` when
their fields are absent; a skip is not proof of successful installation.
This is a selected regression panel, not comprehensive coverage of every
predictor (in particular FuncVEP and GenIA). The
input contains one synthetic sample named `REGRESSION`; it contains no patient
data.

Next: [Annotation dataset setup](DATASET_SETUP.md)
