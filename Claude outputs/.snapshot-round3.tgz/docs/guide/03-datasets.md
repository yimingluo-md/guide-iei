---
title: "Set up the annotation datasets"
parent: User Guide
nav_order: 3
---

# Set up the annotation datasets

GUIDE-IEI draws on several reference datasets, each answering a different
interpretive question: How common is the variant? What transcript consequence
is predicted? Has it been reported clinically? Does it alter splicing or
expression? Does it overlap a regulatory element active in a relevant cell
type?

This chapter explains which datasets are required, which are optional, and
which require registration or a separate license.

All of this is done inside the application, at **Annotate VCF → Set up
annotation datasets**. Each dataset is presented as a card describing in
plain language what it contributes; this chapter is a tour of those cards.

![The dataset setup screen: engine and reference status, one-click download tiles for the exome and WGS profiles, and the registration-gated dbNSFP and PromoterAI cards](../assets/img/dataset-cards.png)

## Plan disk space first

| Dataset | Approximate payload or preparation requirement | Contributes |
|---|---|---|
| Core references (VEP cache, genome FASTA, LOFTEE data, region tracks) | Multiple large archives plus extracted files; see setup's free-space check | required for all analyses |
| dbNSFP (registration required) | ~52 GB | protein-effect predictors |
| SpliceAI MANE SNV scores | 27 GB | splice predictions |
| ENCODE SCREEN + tissue/immune contexts | ~2 GB | WGS regulatory review |
| PromoterAI (licensed; recommended for WGS) | <1 GB | promoter predictions |
| CADD whole-genome (optional) | ~83 GiB | non-coding CADD only |
| LoGoFunc (optional) | ~4 GB | GOF/LOF missense mechanism |
| FuncVEP (optional; licensed) | 4.24 GB source ZIP; 24 GiB free for automatic setup | missense functional-effect scores |
| GenIA (optional; registration required) | source-release dependent; small derived SQLite index | gene–disease, phenotype, and exact-allele evidence |

These are not additive minimum-disk requirements: compressed downloads,
installed files, and temporary preparation space are different quantities.
GB is decimal; GiB is binary (1 GiB is about 1.07 GB). The setup action's
free-space requirement is the practical check for the selected resources,
not a prediction of their final installed size. Keep additional room for
input VCFs, annotation outputs, and the Sample Library. Download time varies substantially with internet connection
and storage speed; large installations may take several hours. The datasets
need not reside on the internal drive: the **Storage** page can place them on
an external SSD, and the application verifies free space before each large
download rather than failing partway.

Selected public reference downloads use a checksum-verified mirror with
official-source fallback; other resources use their documented upstream
source or a user-supplied file/link. Supported interrupted downloads resume.
Schema validation and indexing may continue after downloading finishes.

Before a large first-time transfer, GUIDE-IEI checks that the annotation and
indexing tools are ready. On a clean machine it builds the configured local
tool image at this point. After a software update, it also detects and rebuilds
an image from an older GUIDE-IEI version. This preparation happens before any
multi-hour downloads; no separate installation of bioinformatics command-line
tools is required.

## Step 1 — One click for the public datasets

Two actions install the recommended public resources (not every optional dataset):

- **Recommended for exome** — the core references plus the datasets used in
  exome review.
- **Recommended for WGS** — the exome set plus ENCODE SCREEN tissue and
  immune contexts. Both profiles use the same SpliceAI MANE SNV table;
  the WGS action does not add genome-wide indel scores or optional CADD.
  PromoterAI is also recommended for
  WGS, but because it is licensed it cannot be included in the one-click
  download — it is set up once in Step 3 below.

Progress is reported per dataset. A third action, **Refresh changing
sources** (labelled **Update installed datasets** on the setup screen), checks
for updated ClinVar and ClinGen resources. Annotation runs
record the source versions used, allowing results from different dates to be
compared explicitly.

During the first installation, two independent groups can download at the
same time, so progress messages may alternate between datasets. Concurrency is
limited to two groups to avoid overwhelming a typical workstation or external
drive. All existing checksum and archive validation remains in place.

If setup is interrupted or stops on an error, completed and verified files are
kept. The setup panel shows the error and a **Retry** action; retrying checks
what is already ready and resumes only the missing work.

## Step 2 — dbNSFP: the one registration

dbNSFP assembles the field's protein-effect predictors (AlphaMissense,
CADD, REVEL, SIFT, PolyPhen-2, and others) into a single resource. It is
free for academic use, but its license does not permit redistribution, so
each user registers once:

1. At **[dbnsfp.org/download](https://www.dbnsfp.org/download)**, request
   the free **academic** access using an institutional email address.
2. The instruction email links the current academic release. Copy the private
   link whose filename ends in `_grch38.gz`, not the similarly named
   `_grch37.gz` link. The release number may change over time. An Outlook Safe
   Link is accepted as-is.
3. On the dataset screen, paste that link into the **dbNSFP** card and select
   **Download and install dbNSFP**. GUIDE-IEI derives the matching `.tbi` and
   `.md5` links, downloads all three files with eight resumable connections,
   verifies the published checksum and index, and installs the resource. The
   private link is removed after the job and is not written to the job log or
   configuration.

![The annotation-dataset screen groups registration-gated resources and their setup controls](../assets/img/dataset-dbnsfp-card.png)

## Step 3 — PromoterAI: recommended for whole-genome work

PromoterAI ([Illumina, *Science* 2025](https://www.science.org/doi/10.1126/science.ads7373))
predicts whether a promoter variant alters expression of its gene; scores
range from −1 (under-expression) to +1 (over-expression). The precomputed
scores are **free for academic and non-commercial research** but licensed
by Illumina, so GUIDE-IEI neither downloads nor redistributes them. The
one-time setup:

1. At the
   **[Illumina PromoterAI repository](https://github.com/Illumina/PromoterAI)**,
   follow the access instructions for the precomputed scores: complete the
   non-commercial license agreement, after which the download link arrives
   by email. (Commercial use is licensed separately by Illumina.)
2. Download the two files — `tss.tsv` and `promoterAI_tss500.tsv.gz` —
   into one local folder.
3. On the dataset screen, open the **PromoterAI** card and select that
   folder. Validation and installation are automatic; nothing is uploaded
   anywhere, and the source files are removed only after installation
   succeeds.

PromoterAI annotation applies to whole-genome analysis only, promoters
lying outside the exome's coding scope.

## Step 4 — Optional datasets

- **CADD whole-genome** (~83 GiB). Coding-region CADD scores are already
  present in dbNSFP; this large download adds CADD for **non-coding**
  positions only, as a complement to SpliceAI, PromoterAI, and cCRE
  evidence in whole-genome review.
- **LoGoFunc**
  ([Stein et al., *Genome Medicine* 2023](https://genomemedicine.biomedcentral.com/articles/10.1186/s13073-023-01261-9)).
  Assigns probabilities to neutral, gain-of-function, and loss-of-function
  classes for missense variants. It may provide a mechanistic hypothesis, but
  it does not establish pathogenicity or functional effect. One click from
  Zenodo (~4 GB).
- **FuncVEP**
  ([Kayaalp et al., *Nature Genetics* 2026](https://www.nature.com/articles/s41588-026-02727-3)).
  Scores the predicted functional effect of GRCh38 missense SNVs. It is a
  licensed resource. Review the archive's
  [PolyForm Strict License 1.0.0](https://polyformproject.org/licenses/strict/1.0.0),
  acknowledge that your intended use is permitted, and select **Download and
  install FuncVEP**. GUIDE-IEI downloads the pinned ZIP resumably from the
  [official Zenodo record](https://zenodo.org/records/20595206). You can select
  an existing official ZIP instead.
  The upstream terms permit qualifying noncommercial use but do not grant
  distribution or software-modification rights. Because Zenodo does not expose a separate
  dataset-license field for this record, confirm that your intended local use
  is authorized.
  Preparation happens entirely on this computer. GUIDE-IEI validates the
  archive, retains only the three FuncVEP score columns, builds a local index,
  and retains an automatic download in Annotation datasets storage. Nothing is
  uploaded or redistributed.
  Although the upstream ZIP also contains ClinVEP columns, GUIDE-IEI does not
  import or display ClinVEP.

FuncVEP scores are emitted only when both the genomic allele and the
version-independent Ensembl gene ID match exactly. The three models are CTI
(clinically trained component predictors included), CTE (clinically trained
predictors and AlphaMissense excluded; AlphaMissense used ClinVar variants for
model selection and tuning), and SP (features from other
variant-effect predictors excluded). A higher score means a stronger predicted
functional effect. The final publication's binary cutoffs are CTI
≥0.419606448098318, CTE ≥0.519261866786599, and SP ≥0.440940891937106;
GUIDE-IEI displays **Damaging** or **Neutral** accordingly. These labels are not
clinical pathogenicity classifications or ACMG PP3/BP4 evidence strengths,
and a missing score is not evidence that a variant is neutral or benign.

- **GenIA**
  ([website](https://geniadb.org/);
  [published paper](https://doi.org/10.1016/j.jaci.2023.11.022)). This
  registered-user resource can add immune gene–disease knowledge, reported
  phenotypes, and exact GRCh38 variant records. GUIDE-IEI does not bundle a
  credential, download URL, or GenIA source file. After obtaining the exports,
  open **Import & QC → Set up annotation datasets → User action needed →
  GenIA**, select one or more files, and install them locally.
  GenIA remains optional; this grouping means that the user supplies the
  files, not that annotation requires them. dbNSFP is required separately.

  The five recognized components are **GEI gene–disease list**, **GenIA
  disease catalog**, **disease–phenotype associations**, **GenIA phenotype
  vocabulary**, and **GenIA GRCh38 variants**. Filenames can vary because the
  installer recognizes the schema. Any one or subset works, and updating a
  subset preserves previously installed components that were not selected.
  The VCF's downloaded index is not needed.

  GUIDE-IEI validates the selected data, creates a private derived SQLite
  index with per-component filename, checksum, schema, row-count, and
  installation provenance, and does not copy or retain the source exports.
  Nothing is uploaded. Publication is atomic: if a selected file is a login
  page, has the wrong schema, or otherwise fails, the existing GenIA index
  remains unchanged.

  If the card says the derived GenIA index is unreadable, select all five
  exports for a normal complete recovery. If you have only a subset, select
  those files and check **Replace the unreadable derived GenIA index**. This
  explicit repair keeps only the selected components and removes omitted
  components; you can add those components again later. The replacement is
  still validated before it becomes active.

  Variant records require an exact normalized GRCh38 allele. Source alleles
  containing ambiguous `N` bases are excluded. GenIA labels are shown as
  source evidence, not as a new GUIDE-IEI or ACMG/AMP classification. `NC`
  means **Not classified**, `RF` means **Risk factor**, and neither should be
  read as VUS or pathogenic, respectively. `Relevant_in=0` means zero subjects
  were reported in that export; it does not mean benign. The variant export
  has no gene or disease context, so the exact-allele display does not use the
  selected VEP transcript to invent one.

  Only the **GenIA GRCh38 variants** component enables GenIA protein matching.
  Its `P` and `LP` missense records are prepared with the same VEP cache used
  for the patient VCF. Matches require the same gene, stable Ensembl
  transcript, protein position, and reference amino acid; same-change matches
  also require the same alternate amino acid. An identical genomic allele is
  kept as exact-allele evidence rather than repeated as a protein match. These
  locally derived VEP coordinates support the comparison only; they do not add
  GenIA gene–disease context.

The software includes compact gene-knowledge resources (gnomAD constraint,
HGNC, the IUIS IEI classification, and ClinGen gene–disease validity and
dosage). Large annotation references are separate: the recommended setup
downloads missing SCREEN cCRE/gene-TSS files and GRCh37 conversion data as
well as the other required references. Do not assume that the application
download alone contains these files.

Licensed OMIM data and registered-user GenIA exports are never shipped.
OMIM is under **Optional add-ons**, while GenIA is under **User action needed**
on the same dataset screen. An authorized OMIM user can paste
their four private links for local download and indexing, or select an
institution's already-downloaded copy. GenIA instead accepts authorized local
exports and retains only its derived component database.

## Verifying the installation

The dataset screen itself is the status display: each card reports
installed-or-missing, with versions. Installed required/included resources
remain on; installed optional predictors default to on where applicable and
can be changed for that run. “User action needed” can contain both required
dbNSFP and optional GenIA.

For deeper verification, the regression panel annotates eight public control
variants and asserts selected expected annotations—not every predictor or
every source. Review optional `SKIP` results as well as failures
([Quality control](10-quality-control.md)):

```bash
bash scripts/run_annotation_regression.sh
```

Technical reference: [Annotation dataset setup](../DATASET_SETUP.md) and
[Dataset reference](../dataset-reference.md).

Next: [Your first exome](04-first-exome.md)
