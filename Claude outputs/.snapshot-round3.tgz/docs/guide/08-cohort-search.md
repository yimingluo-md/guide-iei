---
title: "Cohort analysis: review and search"
parent: User Guide
nav_order: 8
---

# Cohort analysis: review and search

GUIDE-IEI supports two complementary cohort questions:

- **Cohort review:** Which variants are present in this jointly called or
  combined dataset, and who carries each one?
- **Cohort search:** Across all locally indexed cases, who carries this variant
  or a qualifying variant in this gene, gene list, or region?

## Cohort review: the variant list, with carriers

Importing a multi-sample VCF (16 or more samples) switches the review
workspace into **cohort review mode** automatically. The change is in what
a row represents: instead of one row per variant per patient, the table
shows **one row per variant**, and the genotype column reports how many
individuals carry it (for example, `3/88 carry`). Every familiar filter
applies unchanged — population frequency, IMPACT, gene lists, predictors,
ClinVar — so the screening loop is the same one used for a single exome.
The **One row per variant** display (on by default) additionally collapses
multiple transcript or gene consequences of the same variant — MANE Select
plus MANE Plus Clinical, or overlapping genes — into a single row with a
+N indicator ([Reading a variant page](09-reading-a-variant.md)).

Opening a variant adds a **Carriers** panel to the evidence: each carrying
individual with genotype, depth, genotype quality, allele depths, and
allele balance. The question this chapter exists for — *which of my 88
patients carry this candidate?* — is answered there, one click deep.

Two capabilities are deliberately absent in cohort mode, because they are
meaningless across a cohort: trio/family analysis and the per-patient
phenotype tab (both remain available when reviewing an individual or a
small family, where rows are per-sample as before — files with 2–15
samples keep the family-oriented behavior unchanged).

**Two forms of carrier count, by provenance.** A jointly called file may
display `3/88 carry` because all 88 individuals were evaluated at the site. A
collection assembled from separately called files displays only `3 carry`,
because absence of a record from another file cannot be interpreted as a
confirmed reference genotype. Aggregated imports also apply the candidate-import popmax
threshold at parse time, warn when the files were annotated against
different ClinVar releases, and refuse duplicate sample names across
files.

**Routes into cohort review:**

- **Import → Review annotated VCF** with either scope. A cohort **exome**
  file (16+ samples) is prepared on the local service automatically under
  the Exome scope: PASS-or-unfiltered records in coding regions, filtered
  by a gnomAD popmax threshold (default ≤ 0.01, set in the **Cohort exome
  candidate import** panel; clear it to keep common variants). A cohort **genome**
  takes the Whole genome scope with its full prefilter (population
  frequency plus the non-coding retention criteria). Either way, the
  prepared result opens in cohort mode, and the prefilter is what keeps
  the carrier volume reviewable.
- **Import → Review annotated VCF** with several exome files at once:
  when the sample columns sum to 16+, the files are aggregated as
  separately called (above).
- **Sample Library → any selection → Open combined review**: a selection
  within one source file keeps joint semantics; a selection spanning
  files — including Select all over a heterogeneous library — opens as a
  separately-called aggregation.

## Reviewing individuals and subsets from a cohort

The Sample Library shows an imported cohort as one callset card; expand its
sample list to work with individual samples. From there:

- **Open review** on one individual opens a normal single-patient review —
  the service projects that person's genotype column and carried variants
  from the stored file.
- **Select several individuals** (checkboxes, or **Select all**) and
  **Open combined review** — for example, three affected members of one
  family within the cohort. With 15 or fewer selected, the review behaves
  like a family file, including trio analysis when applicable; with 16 or
  more, cohort mode applies. Selecting every individual reopens the whole
  cohort.
- **Remove selected** deletes the chosen datasets from the library and
  Cohort Search in one action, after confirmation; original source VCFs
  are never deleted.

## Cohort search: genotype-first questions

Cohort review answers "what variants are here, and who carries each."
**Cohort search** answers the inverse: *who carries qualifying variants in
this gene?* or *who carries this exact variant?* — across every indexed
case, not only one import. Membership is managed entirely through the
**Sample Library**: keep a review with "Include qualifying variants in
Cohort Search" enabled, or use the library's per-dataset and bulk actions
(Add to Cohort Search, Remove selected). The records live in a local
database on this workstation.

Four query forms: an **exact variant** (locus or rsID — alleles are matched
by their minimal representation, so `1:100:AT:ATT` and `1:100:A:AT` find the
same carriers, and results display that canonical form); **qualifying
variants in one gene**; a **gene list** — paste symbols or insert a saved
list from Gene lists (an IUIS panel, a custom panel), up to 2,000 genes
per query; and a **genomic region** (`chrom:start-end`, up to 5 Mb) for
non-coding questions — who carries anything in this enhancer window, this
promoter, this topological neighborhood. Opening the region tab selects
all IMPACT tiers, because non-coding records are MODIFIER and the coding
default would hide them. The gene and region forms share the qualifying
filters (impact, popmax, predictors, ClinVar). This is the scalable route for large collections:
screening 50 genomes against a panel is one query, and only the matched
findings are ever opened. Matched findings flow into the review
workspace with each record re-read from its source, so every evidence
field the variant page displays reflects the full record.

When a new gene–disease association is published, this is the two-minute
check across the entire collection — without touching the original files.

The **Genotype** control narrows carriers by stored zygosity, which follows
how each file encoded the call. A male's single X or Y copy outside the
pseudoautosomal regions is written haploid (`1`, stored *hemizygous*) by
some callers and diploid-style (`1/1`, stored *homozygous*) by others, so at
those single-copy loci the **Homozygous** and **Hemizygous** searches each
include the other class; elsewhere they stay distinct. Recorded sex from the
Phenotypes tab narrows this where it is known: a `1/1` on non-PAR X in an
individual recorded as *female* is a genuine two-copy call and is left out of
a hemizygous search, while male, other, unknown and unlinked samples keep the
widening. A haploid call is single-copy whatever the recorded sex and stays in
both searches. Nothing is re-coded — each result still shows its own genotype
and stored class — so a hemizygous search on a cohort without phenotype
records will also list female X homozygotes; link samples to individuals with
sex at birth to exclude them.

## Building a large collection: bulk import

**Bulk Import** automatically processes annotated VCFs one at a time, applying
candidate filters and adding each retained dataset to the Sample Library. By
default, each sample is also added to Cohort Search as it is imported. Use
Cohort Search to query the full collection, and open a combined browser review
only for a manageable subset of individuals.

Three properties matter at scale:

- **It resumes.** The queue is recorded on disk. Close the app or restart
  the workstation mid-batch and the remaining files pick up where they
  left off; nothing is imported twice.
- **One failure is one failure.** A truncated or mis-annotated file is
  recorded with its error and the queue moves on. The status card lists
  every failed file for review; the rest of the batch is unaffected.
- **Serial on purpose.** One file at a time keeps memory flat and leaves
  the workstation usable; a genome's own prefilter dominates the time, so
  parallelism would buy little and cost stability.

A 1,000-genome collection is a design target, not a validated performance
specification. Benchmark a small representative batch on your workstation
before scheduling the full collection, and check per-file outcomes afterward.
The collection is queried rather than opened wholesale. The library lists
25 callsets per page; search and bulk actions cover the collection, not only
the visible page. Query time depends on database size, disk, and result count.

## Bounds worth knowing

The following are approximate operational limits observed during development,
not validated performance specifications.

- **Review size.** A browser review stays responsive to roughly 350,000
  transcript rows. A retained exome is saved and indexed first; if its full
  transcript expansion crosses that boundary, the browser list uses MANE,
  VEP PICK, or one per-gene fallback while the complete transcript table is
  restored for an opened variant. A **Review once** import cannot use that
  managed fallback and is refused with directions instead. Imports beyond
  ~3 million carrier genotypes for unfiltered callsets are also refused.
  Large multi-sample collections belong in Cohort Search, which queries its
  local index instead of materializing every row in the browser.
- **No cohort allele frequencies.** The software deliberately does not
  compute them: callability, capture, and retention profiles are not
  comparable across heterogeneous imports. Positive carrier findings are
  meaningful; absence from an index is not evidence of absence.
- **Annotation granularity.** Cohort rows carry the same per-transcript
  annotation as any review; carrier evidence is genotype-level. Full
  sample FORMAT evidence for any record is restored on demand when opened.

Technical reference: [The review workbench](../REVIEW_WORKBENCH.md).

Next: [Reading a variant page](09-reading-a-variant.md)
