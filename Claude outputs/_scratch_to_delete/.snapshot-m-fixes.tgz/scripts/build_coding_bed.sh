#!/usr/bin/env bash
# =============================================================================
# build_coding_bed.sh — build the coding-exon + splice-site BED used to
# restrict annotation to the clinically-interpretable fraction of the genome.
#
# Source: the release-matched Ensembl GTF (same Ensembl release as your VEP
# offline cache, so contig names and coordinates line up exactly — no `chr`
# stripping needed, unlike the UCSC tracks).
#
# Output: references/regions/coding_splice.padded.bed.gz (+ .tbi)
#   * CDS/stop-codon features plus splice windows centered on the actual exon
#     boundaries of protein-coding transcripts, then merged.
#
# Usage:
#   scripts/build_coding_bed.sh [config.yaml] [--force]
# =============================================================================
set -euo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${HERE}/lib.sh"
ROOT="$(cd "${HERE}/.." && pwd)"

CONFIG="${1:-${ROOT}/config/annotation.config.yaml}"
[[ "$CONFIG" == --* ]] && CONFIG="${ROOT}/config/annotation.config.yaml"
FORCE=0
for a in "$@"; do [[ "$a" == "--force" ]] && FORCE=1; done
[[ -f "$CONFIG" ]] || die "config not found: $CONFIG"

# hts() falls back to the container when host bgzip/tabix/samtools are absent;
# honour the configured runtime/image instead of the docker/vep-annotate:latest
# defaults (a podman-only host previously failed here despite correct config).
RUNTIME="$(yaml_get "$CONFIG" container.runtime)"; RUNTIME="${RUNTIME:-docker}"
IMAGE="$(yaml_get "$CONFIG" container.image)";     IMAGE="${IMAGE:-vep-annotate:latest}"
export RUNTIME IMAGE

absdir() { local p="$1"; [[ "$p" = /* ]] && echo "$p" || echo "${ROOT}/${p}"; }

ASSEMBLY="$(yaml_get "$CONFIG" reference.assembly)"; ASSEMBLY="${ASSEMBLY:-GRCh38}"
VEP_TAG="$(yaml_get "$CONFIG" container.vep_image_tag)"
VEP_REL="$(echo "$VEP_TAG" | sed -E 's/[^0-9]*([0-9]+).*/\1/')"; VEP_REL="${VEP_REL:-113}"
PAD="$(yaml_get "$CONFIG" region.padding_bp)"; PAD="${PAD:-8}"
# absdir("") returns "${ROOT}/" (non-empty), which would defeat the default
# below and later mv the built BED onto a directory path — resolve only when
# the key is actually set.
BED_RAW="$(yaml_get "$CONFIG" region.bed)"
if [[ -n "$BED_RAW" ]]; then
    BED="$(absdir "$BED_RAW")"
else
    BED="${ROOT}/references/regions/coding_splice.padded.bed.gz"
fi
CUSTOM="$(yaml_get "$CONFIG" region.custom_bed)"

# If the user supplied a custom BED, we never build from the GTF.
if [[ -n "$CUSTOM" ]]; then
    log "region.custom_bed set ($CUSTOM) — build_coding_bed.sh has nothing to do."
    exit 0
fi

if [[ -s "$BED" && "$FORCE" != "1" ]]; then
    log "coding BED already present: $BED  (use --force to rebuild)"
    exit 0
fi

mkdir -p "$(dirname "$BED")"
GTF_URL="https://ftp.ensembl.org/pub/release-${VEP_REL}/gtf/homo_sapiens/Homo_sapiens.${ASSEMBLY}.${VEP_REL}.gtf.gz"
RAW="$(dirname "$BED")/Homo_sapiens.${ASSEMBLY}.${VEP_REL}.gtf.gz"

log "=== coding+splice BED (Ensembl release $VEP_REL, $ASSEMBLY, pad ${PAD}bp) ==="
if [[ ! -s "$RAW" ]]; then
    log "fetching $GTF_URL"
    fetch "$GTF_URL" "$RAW" || die "Ensembl GTF download failed: $GTF_URL"
fi

# Padding is clamped to >= 0 at the low end only; a right end past the contig
# is tolerated by VEP. (A planned .fai-derived contig-length clamp was never
# implemented — the dangling FAI= assignment that documented it is removed.)

TMP="$(mktemp)"
MERGED=""
# Clean both interval temps on any failure — these are multi-hundred-MB
# GTF-derived files, and every sibling build script installs a trap.
trap 'rm -f "$TMP" ${MERGED:+"$MERGED"}' EXIT
# Extract CDS + stop_codon (stop_codon is a separate GTF feature but is coding)
# and true exon-junction windows for protein-coding transcripts. Using only
# padded CDS edges misses splice sites when a UTR separates the CDS from the
# exon boundary. Convert GTF [1-based, inclusive] -> BED [0-based, half-open]
# and clamp low coordinates to 0.
# `zcat` on macOS is the legacy .Z reader; `gzip -cd` is portable for .gz.
gzip -cd "$RAW" \
  | awk -v pad="$PAD" 'BEGIN{FS=OFS="\t"}
      $3=="CDS" || $3=="stop_codon" {
        s=$4-1-pad; if(s<0)s=0;
        e=$5+pad;
        print $1, s, e
      }
      $3=="exon" && ($9 ~ /transcript_biotype "protein_coding"/ || $9 ~ /gene_biotype "protein_coding"/) {
        left=$4-1; s=left-pad; if(s<0)s=0; print $1, s, left+pad;
        right=$5; s=right-pad; if(s<0)s=0; print $1, s, right+pad
      }' \
  | sort -k1,1 -k2,2n > "$TMP"

NFEAT=$(wc -l < "$TMP" | tr -d ' ')
[[ "$NFEAT" -gt 0 ]] || die "no coding or exon-boundary features parsed from $RAW"
log "parsed $NFEAT coding and exon-boundary intervals; merging"

# Merge overlapping/adjacent intervals (pure awk, no bedtools dependency).
MERGED="$(mktemp)"
awk 'BEGIN{FS=OFS="\t"; pc=""; ps=-1; pe=-1}
  {
    if($1==pc && $2<=pe){ if($3>pe) pe=$3 }
    else { if(pc!="") print pc, ps, pe; pc=$1; ps=$2; pe=$3 }
  }
  END{ if(pc!="") print pc, ps, pe }' "$TMP" > "$MERGED"

NMERGED=$(wc -l < "$MERGED" | tr -d ' ')
BPTOTAL=$(awk '{s+=$3-$2} END{printf "%.1f", s/1e6}' "$MERGED")
log "merged -> $NMERGED intervals covering ~${BPTOTAL} Mb"

# bgzip + tabix (via container passthrough if no host bgzip/tabix).
PLAIN="${BED%.gz}"
mv "$MERGED" "$PLAIN"
rm -f "$TMP"
( cd "$(dirname "$BED")" && hts bgzip -f "$(basename "$PLAIN")" )
( cd "$(dirname "$BED")" && hts tabix -f -p bed "$(basename "$BED")" )

log "coding+splice BED ready: $BED"
log "Restriction is ON by default (region.coding_only: true). To annotate ALL"
log "variants (WGS / non-coding), set region.coding_only: false or pass --all-variants."
